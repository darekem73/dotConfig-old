conky -d -c ~/.conkyrc-stat
#conky -d -c ~/.conkyrc-hlp

